/*
  loader.h
  Copyright (C) 1996 Toyohashi University of Technology
*/

#ifndef EOF
#include <stdio.h>
#endif
void loader(FILE *);
